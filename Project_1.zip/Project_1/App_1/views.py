from django.shortcuts import render
from App_1.models import Country,State,District
import requests
from django.http import JsonResponse
# Create your views here.

def zone_api_data():
    api_url = 'http://13.200.33.105/SWMServiceLive/SWMService.svc/GetZone'
    
    payload = {
                "mode": 11,
                "vehicleId": 0,
                "AccId": 11401
            }
    response = requests.post(api_url, json=payload)
    data = response.json()  # Assuming the API response is in JSON format
    # print('Printing data--',data)
    zone=data['GetZoneResult']['ZoneMasterList']
    return zone



def get_api_data():
    api_url = 'http://13.200.33.105/SWMServiceLive/SWMService.svc/GetWard'
    
    payload = {
            "mode": 12,
            "vehicleId": 0,
            "AccId": 11401,
            "ZoneId": 103
            }
    response = requests.post(api_url, json=payload)
    data = response.json()  # Assuming the API response is in JSON format
    # print('Printing data--',data)
    ward=data['GetWardResult']['WardMasterList']
    return ward

def dependentfield(request):
    country_id = request.GET.get('country',None)
    stateid=request.GET.get('state',None)
    data=get_api_data()
    zone_data=zone_api_data()
    # print('Country-id-',country_id)
    # print('State-id',stateid)
    ward=None
    kothi=None
    print(zone_data)
    # ---------------------------------
    # if country_id:
    #     print('======')
    #     getcountry=Country.objects.get(id=country_id)
    #     # print("Get-Country--",getcountry)
    #     state=State.objects.filter(country=getcountry)
    # if stateid:
    #     getstate=State.objects.get(id=stateid)
    #     district=District.objects.filter(state=getstate)
    # -------------------------------
    # if zone_data:
    #     for i in zone_data:
    #         if i['zoneid']  '102':

    #     # print(zone_data['zoneid'])
    #     # print(zone_id)
    # # if ward:


    # country=Country.objects.all()
    return render(request,'dependentfield.html',locals())