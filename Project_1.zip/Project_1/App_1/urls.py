from django.contrib import admin
from django.urls import path,include
from App_1.views import dependentfield,get_api_data

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', dependentfield, name='dependentfield'),
    path('data/',get_api_data,name='data')
]