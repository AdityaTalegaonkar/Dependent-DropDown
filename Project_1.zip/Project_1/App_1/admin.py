from django.contrib import admin

# Register your models here.

from App_1.models import Country,State,District

admin.site.register(Country)
admin.site.register(State)
admin.site.register(District)